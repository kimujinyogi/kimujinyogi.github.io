# Meet the users of Terminal theme!
- https://xicode.se **magistern** (Teacher)
- https://devmaster64.com **devmaster64** (Software Developer)
- https://mickie1.gitlab.io/blog/ **mickie** (Engineer)
- https://calloc.net **Vaibhav Yenamandra** (Software Engineer)
- https://potatofrom.space **Kevin Liu** (Software)
- https://horochx.org **horochx** (Software Developer)
- https://feng.si **Si Feng** (Software Engineer)
- https://ben-on-vms.com **Benedikt Frenzel** (Technical Support Engineer)
- https://johngazzini.com **John Gazzini** (Software Engineer)
- https://geekx.tech/ **Sagar Ladla** (Student Developer & Cyber Security Specialist)
- https://tears.io/ **Alex** (SRE)
- https://ayushkarn.me/ **Ayush Karn** (Student Developer)
- https://ssgram.dev **Ramaseshan Parthasarathy** (Software Developer)
- https://zaine.me **Amine Zaine** (Cloud Engineer)
- https://notes.dmaitre.phyip3.dur.ac.uk/computing-club/ **Ryan Moodie** (Physics PhD student)
- https://thecodecousins.com **Stanley Nguyen** (Software Engineer) & **Hoang Do** (Software & IoT Engineer)
- https://schacherbauer.dev **Markus Schacherbauer** (Student Developer)
- https://rinma.dev **Marvin Dalheimer** (Software Developer)
- https://lunar.computer **Lunar Computer** (DevOps Engineer)
- https://naxxfish.net **Chris Roberts** (Broadcast SYstems Engineerr)

<!--
TEMPLATE:

- https://radoslawkoziel.pl **Radek Kozieł** (Software Designer and Developer)

-->
